#include "mainscreen.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    mainScreen w;
    a.setQuitOnLastWindowClosed(false);
    a.setApplicationName("DoublePulsar Antivirus");
    a.setApplicationDisplayName("DoublePulsar Antivirus");
    a.setApplicationVersion("0.1.0");
    w.setWindowTitle(a.applicationName()+QString(" V%1 ").arg(a.applicationVersion()));
    w.show();
    return a.exec();
}
