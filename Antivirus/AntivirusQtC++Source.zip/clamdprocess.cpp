#include "clamdprocess.h"

clamdProcess::clamdProcess()
{

}
