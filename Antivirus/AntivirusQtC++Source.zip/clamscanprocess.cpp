#include "clamscanprocess.h"

clamscanProcess::clamscanProcess()
{

}
