#include "freshclamprocess.h"

freshclamProcess::freshclamProcess()
{

}
