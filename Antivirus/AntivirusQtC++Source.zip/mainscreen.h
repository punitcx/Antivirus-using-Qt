#ifndef MAINSCREEN_H
#define MAINSCREEN_H

#include <QDebug>
#include <QMessageBox>
#include <QSystemTrayIcon>
#include <QMenu>
#include <QAction>
#include <QMainWindow>
#include <QFile>
#include <QFileDialog>
#include <QInputDialog>
#include <QCloseEvent>
#include <QStringListModel>
#include <QTime>
#include <QTimer>
#include <QElapsedTimer>
#include <clamdprocess.h>
#include <clamdscanprocess.h>
#include <clamscanprocess.h>
#include <freshclamprocess.h>
#include <customthread.h>

QT_BEGIN_NAMESPACE
namespace Ui { class mainScreen; }
QT_END_NAMESPACE

class mainScreen : public QMainWindow
{
    Q_OBJECT

public:
    mainScreen(QWidget *parent = nullptr);
    ~mainScreen();

private:
    void closeEvent(QCloseEvent *event);
    void changeEvent(QEvent *event);
private slots:

    void setTrayIcon();

    void countFiles(QString path);

    void filesCounterStarted();

    void doInitialization();

    QStringList buildArguments(QString fromFile, QString wait, QString log, QString action, QString multiscan);

    QStringList buildArguments(bool notCustom,QString dirName, QString wait, QString log, QString action);

    void startClamdInstance();

    void clamdStarted();

    void handleClamdProcessError(QProcess::ProcessError error);

    void readClamdOutput();

    void stopClamdInstance();

    void startClamdscan(QStringList arguments);

    void handleClamdscanProcessError(QProcess::ProcessError error);

    void readClamdscanOutput();

    void clamdscanStarted();

    void stopClamdscan();

    void updateElapsedTime();

    void setDefaultActionText();

    void on_statusButton_clicked();

    void on_speedUpButton_clicked();

    void on_optimizerButton_clicked();

    void on_settingsButton_clicked();

    void on_stopScanButton_clicked();

    void on_fullVirusScan_clicked();

    void on_selectDirectoryButton_clicked();

    void on_selectFilesButtonn_clicked();

    void on_customScan_clicked();

    void on_startCustomScanButton_clicked();

    void addScanItemsToFile();

    void on_targetedScan_clicked();

    void continueCustomScan();

    void killClamd();

    void on_performQuickScanButton_clicked();

    void showEngineInformation();

    void showFreshClamOutput();

    void showClamdOutputAsStatus();

    void showStatusMessage(QString message);

    void on_updateDatabase_clicked();

    void on_showLogs_clicked();

    void on_moveToQuarantine_toggled(bool checked);

    void on_copyToQuarantine_toggled(bool checked);

    void on_deleteVirus_toggled(bool checked);

    void on_backButton_clicked();

    void showTrayMessage(QString title, QString message, int msecs=4000);

    void doQuickScan();

    void updateVirusDatabase();

    void enableSilentMode();

    void exitNicely();

    void on_scanForJunk_clicked();

    void on_stayOnTop_toggled(bool checked);

private:
    Ui::mainScreen *ui;
    QSystemTrayIcon *trayIcon;
    QMenu *trayMenu;
    QAction *actionOpenAntivirus,*actionCloseAntivirus,*actionQuickScan,*actionUpdateDatabase,*actionEnableSilentMode;


    customThread *filesCounter;
    clamdProcess *clamd;
    clamdscanProcess *clamdscan;
    clamscanProcess *clamscan;
    freshclamProcess *freshclam;

    QElapsedTimer elapsedTimer;
    QTimer *timer;

    int filesScanned=0,threats=0;
    bool silent=false;
    bool customFinished=true;
    bool quickscan=false;
    bool scanningStarted=false;

    QString scanItemsFileName="files.txt",logFileName="scanlog.txt";
    QString quarantineDir="C:\\quarantine";
    QString defaultAction="copy";
    QStringListModel scanItemsListModel;
    QStringList scanItemsList;
    QString scanTitle="Scanning";
    QString applicationName="DoublePulsar Antivirus";
    QString secureStatusString="Your System Is Secure";
    QString clamBaseDir="C:\\Users\\Green\\Desktop\\Projects\\Antivirus\\clamav-0.103.2-win-x86-portable\\";

};
#endif // MAINSCREEN_H
