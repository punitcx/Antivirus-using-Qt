#ifndef CLAMSCANPROCESS_H
#define CLAMSCANPROCESS_H

#include <QProcess>

class clamscanProcess : public QProcess
{
    Q_OBJECT
public:
    clamscanProcess();
};

#endif // CLAMSCANPROCESS_H
