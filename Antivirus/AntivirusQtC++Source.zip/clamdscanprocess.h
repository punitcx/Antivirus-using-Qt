#ifndef CLAMDSCANPROCESS_H
#define CLAMDSCANPROCESS_H

#include <QProcess>

class clamdscanProcess : public QProcess
{
    Q_OBJECT
public:
    clamdscanProcess();
};

#endif // CLAMDSCANPROCESS_H
