#ifndef CLAMDPROCESS_H
#define CLAMDPROCESS_H

#include <QProcess>

class clamdProcess : public QProcess
{
    Q_OBJECT
public:
    clamdProcess();
};

#endif // CLAMDPROCESS_H
