#ifndef FRESHCLAMPROCESS_H
#define FRESHCLAMPROCESS_H

#include <QProcess>

class freshclamProcess : public QProcess
{
    Q_OBJECT
public:
    freshclamProcess();
};

#endif // FRESHCLAMPROCESS_H
