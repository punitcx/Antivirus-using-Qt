#include "clamdscanprocess.h"

clamdscanProcess::clamdscanProcess()
{

}
